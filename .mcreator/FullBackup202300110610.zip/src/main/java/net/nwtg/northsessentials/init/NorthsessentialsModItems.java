
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.nwtg.northsessentials.init;

import net.nwtg.northsessentials.NorthsessentialsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class NorthsessentialsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NorthsessentialsMod.MODID);
	public static final RegistryObject<Item> COAL_NODE = block(NorthsessentialsModBlocks.COAL_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> COPPER_NODE = block(NorthsessentialsModBlocks.COPPER_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> IRON_NODE = block(NorthsessentialsModBlocks.IRON_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> EMERALD_NODE = block(NorthsessentialsModBlocks.EMERALD_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> GOLD_NODE = block(NorthsessentialsModBlocks.GOLD_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> LAPIS_NODE = block(NorthsessentialsModBlocks.LAPIS_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> REDSTONE_NODE = block(NorthsessentialsModBlocks.REDSTONE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> DIAMOND_NODE = block(NorthsessentialsModBlocks.DIAMOND_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> COAL_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.COAL_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> COPPER_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.COPPER_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> IRON_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.IRON_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> EMERALD_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMERALD_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> GOLD_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.GOLD_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> LAPIS_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.LAPIS_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> REDSTONE_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.REDSTONE_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> DIAMOND_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.DIAMOND_DEEPSLATE_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> QUARTZ_NODE = block(NorthsessentialsModBlocks.QUARTZ_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> NETHER_GOLD_NODE = block(NorthsessentialsModBlocks.NETHER_GOLD_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> EMPTY_GOLD_NODE = block(NorthsessentialsModBlocks.EMPTY_GOLD_NODE, null);
	public static final RegistryObject<Item> EMPTY_COPPER_NODE = block(NorthsessentialsModBlocks.EMPTY_COPPER_NODE, null);
	public static final RegistryObject<Item> EMPTY_COAL_NODE = block(NorthsessentialsModBlocks.EMPTY_COAL_NODE, null);
	public static final RegistryObject<Item> EMPTY_IRON_NODE = block(NorthsessentialsModBlocks.EMPTY_IRON_NODE, null);
	public static final RegistryObject<Item> EMPTY_EMERALD_NODE = block(NorthsessentialsModBlocks.EMPTY_EMERALD_NODE, null);
	public static final RegistryObject<Item> EMPTY_LAPIS_NODE = block(NorthsessentialsModBlocks.EMPTY_LAPIS_NODE, null);
	public static final RegistryObject<Item> EMPTY_REDSTONE_NODE = block(NorthsessentialsModBlocks.EMPTY_REDSTONE_NODE, null);
	public static final RegistryObject<Item> EMPTY_DIAMOND_NODE = block(NorthsessentialsModBlocks.EMPTY_DIAMOND_NODE, null);
	public static final RegistryObject<Item> EMPTY_QUARTZ_NODE = block(NorthsessentialsModBlocks.EMPTY_QUARTZ_NODE, null);
	public static final RegistryObject<Item> EMPTY_COAL_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_COAL_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_COPPER_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_COPPER_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_IRON_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_IRON_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_EMERALD_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_EMERALD_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_GOLD_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_GOLD_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_LAPIS_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_LAPIS_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_REDSTONE_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_REDSTONE_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_DIAMOND_DEEPSLATE_NODE = block(NorthsessentialsModBlocks.EMPTY_DIAMOND_DEEPSLATE_NODE, null);
	public static final RegistryObject<Item> EMPTY_NETHER_GOLD_NODE = block(NorthsessentialsModBlocks.EMPTY_NETHER_GOLD_NODE, null);
	public static final RegistryObject<Item> EMPTY_AMETHYST_NODE = block(NorthsessentialsModBlocks.EMPTY_AMETHYST_NODE, null);
	public static final RegistryObject<Item> AMETHYST_NODE = block(NorthsessentialsModBlocks.AMETHYST_NODE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> EMPTY_ANCIENT_DEBRIS_NODE = block(NorthsessentialsModBlocks.EMPTY_ANCIENT_DEBRIS_NODE, null);
	public static final RegistryObject<Item> ANCIENT_DEBRIS_NODE = block(NorthsessentialsModBlocks.ANCIENT_DEBRIS_NODE, CreativeModeTab.TAB_DECORATIONS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
