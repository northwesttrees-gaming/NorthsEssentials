
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.nwtg.northsessentials.init;

import net.nwtg.northsessentials.block.entity.RedstoneNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.RedstoneDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.QuartzNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.NetherGoldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.LapisNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.LapisDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.IronNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.IronDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.GoldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.GoldDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyRedstoneNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyRedstoneDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyQuartzNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyNetherGoldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyLapisNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyLapisDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyIronNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyIronDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyGoldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyGoldDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyEmeraldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyEmeraldDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyDiamondNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyDiamondDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyCopperNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyCopperDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyCoalNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyCoalDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyAncientDebrisNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmptyAmethystNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmeraldNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.EmeraldDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.DiamondNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.DiamondDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.CopperNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.CopperDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.CoalNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.CoalDeepslateNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.AncientDebrisNodeBlockEntity;
import net.nwtg.northsessentials.block.entity.AmethystNodeBlockEntity;
import net.nwtg.northsessentials.NorthsessentialsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

public class NorthsessentialsModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, NorthsessentialsMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> COAL_NODE = register("coal_node", NorthsessentialsModBlocks.COAL_NODE, CoalNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COPPER_NODE = register("copper_node", NorthsessentialsModBlocks.COPPER_NODE, CopperNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> IRON_NODE = register("iron_node", NorthsessentialsModBlocks.IRON_NODE, IronNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMERALD_NODE = register("emerald_node", NorthsessentialsModBlocks.EMERALD_NODE, EmeraldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> GOLD_NODE = register("gold_node", NorthsessentialsModBlocks.GOLD_NODE, GoldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> LAPIS_NODE = register("lapis_node", NorthsessentialsModBlocks.LAPIS_NODE, LapisNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> REDSTONE_NODE = register("redstone_node", NorthsessentialsModBlocks.REDSTONE_NODE, RedstoneNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DIAMOND_NODE = register("diamond_node", NorthsessentialsModBlocks.DIAMOND_NODE, DiamondNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COAL_DEEPSLATE_NODE = register("coal_deepslate_node", NorthsessentialsModBlocks.COAL_DEEPSLATE_NODE, CoalDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COPPER_DEEPSLATE_NODE = register("copper_deepslate_node", NorthsessentialsModBlocks.COPPER_DEEPSLATE_NODE, CopperDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> IRON_DEEPSLATE_NODE = register("iron_deepslate_node", NorthsessentialsModBlocks.IRON_DEEPSLATE_NODE, IronDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMERALD_DEEPSLATE_NODE = register("emerald_deepslate_node", NorthsessentialsModBlocks.EMERALD_DEEPSLATE_NODE, EmeraldDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> GOLD_DEEPSLATE_NODE = register("gold_deepslate_node", NorthsessentialsModBlocks.GOLD_DEEPSLATE_NODE, GoldDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> LAPIS_DEEPSLATE_NODE = register("lapis_deepslate_node", NorthsessentialsModBlocks.LAPIS_DEEPSLATE_NODE, LapisDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> REDSTONE_DEEPSLATE_NODE = register("redstone_deepslate_node", NorthsessentialsModBlocks.REDSTONE_DEEPSLATE_NODE, RedstoneDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DIAMOND_DEEPSLATE_NODE = register("diamond_deepslate_node", NorthsessentialsModBlocks.DIAMOND_DEEPSLATE_NODE, DiamondDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> QUARTZ_NODE = register("quartz_node", NorthsessentialsModBlocks.QUARTZ_NODE, QuartzNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> NETHER_GOLD_NODE = register("nether_gold_node", NorthsessentialsModBlocks.NETHER_GOLD_NODE, NetherGoldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_GOLD_NODE = register("empty_gold_node", NorthsessentialsModBlocks.EMPTY_GOLD_NODE, EmptyGoldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_COPPER_NODE = register("empty_copper_node", NorthsessentialsModBlocks.EMPTY_COPPER_NODE, EmptyCopperNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_COAL_NODE = register("empty_coal_node", NorthsessentialsModBlocks.EMPTY_COAL_NODE, EmptyCoalNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_IRON_NODE = register("empty_iron_node", NorthsessentialsModBlocks.EMPTY_IRON_NODE, EmptyIronNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_EMERALD_NODE = register("empty_emerald_node", NorthsessentialsModBlocks.EMPTY_EMERALD_NODE, EmptyEmeraldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_LAPIS_NODE = register("empty_lapis_node", NorthsessentialsModBlocks.EMPTY_LAPIS_NODE, EmptyLapisNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_REDSTONE_NODE = register("empty_redstone_node", NorthsessentialsModBlocks.EMPTY_REDSTONE_NODE, EmptyRedstoneNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_DIAMOND_NODE = register("empty_diamond_node", NorthsessentialsModBlocks.EMPTY_DIAMOND_NODE, EmptyDiamondNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_QUARTZ_NODE = register("empty_quartz_node", NorthsessentialsModBlocks.EMPTY_QUARTZ_NODE, EmptyQuartzNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_COAL_DEEPSLATE_NODE = register("empty_coal_deepslate_node", NorthsessentialsModBlocks.EMPTY_COAL_DEEPSLATE_NODE, EmptyCoalDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_COPPER_DEEPSLATE_NODE = register("empty_copper_deepslate_node", NorthsessentialsModBlocks.EMPTY_COPPER_DEEPSLATE_NODE, EmptyCopperDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_IRON_DEEPSLATE_NODE = register("empty_iron_deepslate_node", NorthsessentialsModBlocks.EMPTY_IRON_DEEPSLATE_NODE, EmptyIronDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_EMERALD_DEEPSLATE_NODE = register("empty_emerald_deepslate_node", NorthsessentialsModBlocks.EMPTY_EMERALD_DEEPSLATE_NODE, EmptyEmeraldDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_GOLD_DEEPSLATE_NODE = register("empty_gold_deepslate_node", NorthsessentialsModBlocks.EMPTY_GOLD_DEEPSLATE_NODE, EmptyGoldDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_LAPIS_DEEPSLATE_NODE = register("empty_lapis_deepslate_node", NorthsessentialsModBlocks.EMPTY_LAPIS_DEEPSLATE_NODE, EmptyLapisDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_REDSTONE_DEEPSLATE_NODE = register("empty_redstone_deepslate_node", NorthsessentialsModBlocks.EMPTY_REDSTONE_DEEPSLATE_NODE, EmptyRedstoneDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_DIAMOND_DEEPSLATE_NODE = register("empty_diamond_deepslate_node", NorthsessentialsModBlocks.EMPTY_DIAMOND_DEEPSLATE_NODE, EmptyDiamondDeepslateNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_NETHER_GOLD_NODE = register("empty_nether_gold_node", NorthsessentialsModBlocks.EMPTY_NETHER_GOLD_NODE, EmptyNetherGoldNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_AMETHYST_NODE = register("empty_amethyst_node", NorthsessentialsModBlocks.EMPTY_AMETHYST_NODE, EmptyAmethystNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> AMETHYST_NODE = register("amethyst_node", NorthsessentialsModBlocks.AMETHYST_NODE, AmethystNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EMPTY_ANCIENT_DEBRIS_NODE = register("empty_ancient_debris_node", NorthsessentialsModBlocks.EMPTY_ANCIENT_DEBRIS_NODE, EmptyAncientDebrisNodeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ANCIENT_DEBRIS_NODE = register("ancient_debris_node", NorthsessentialsModBlocks.ANCIENT_DEBRIS_NODE, AncientDebrisNodeBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
